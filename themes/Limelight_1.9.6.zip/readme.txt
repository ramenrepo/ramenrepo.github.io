To install Limelight for both Snowboard and Anemone

SSH the extracted '.theme' folders directly to ~/Library/Themes in your device